# README
Due to cross origin policy in browsers, you will likely need to run a web server to serve the HTML files as static pages in order to correctly see the style sheets.
To do this, simply run `python3 -m http.server` in this directory and then open the HTML files.
