#!/usr/bin/env python
import json
from tqdm import tqdm
from lib.query import Query
from lib.common import count_lines

# https://stackabuse.com/reading-and-writing-json-to-a-file-in-python/
if __name__ == '__main__':
    files = {'data/dev.jsonl':'data/dev_query.jsonl','data/test.jsonl':'data/test_query.jsonl','data/train.jsonl':'data/train_query.jsonl'}

    for inputFile, outputFile in files.items():
        with open(inputFile) as fs, open(outputFile, 'a+') as ft:
            for ls in tqdm(fs, total=count_lines(inputFile)):
                eg = json.loads(ls)
                queryString = Query.from_dict(eg['sql'])
                eg['queryString'] = str(queryString)
                # json.dump(eg,ft,indent=4) # Dump an object to a file with specify indent
                json.dump(eg, ft)
                ft.write('\n')
            fs.close()
            ft.close()